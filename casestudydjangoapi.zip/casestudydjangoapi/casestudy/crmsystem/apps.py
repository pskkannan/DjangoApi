from django.apps import AppConfig


class CrmsystemConfig(AppConfig):
    name = 'crmsystem'
